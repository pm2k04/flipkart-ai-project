import os

def generate_product_description(product_name: str, category: str):
    # Mock response since Gemini API is removed
    return f"🔥 check out this amazing {product_name}! It's the best in {category}. Grab it now! #Flipkart #{category}"

def generate_details_with_llm(name: str):
    return generate_product_description(name, "General")
