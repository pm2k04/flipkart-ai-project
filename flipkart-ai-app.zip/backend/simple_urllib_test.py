
import urllib.request
import urllib.error

url = "https://www.flipkart.com/samsung-crystal-4k-infinity-vision-108-cm-43-inch-ultra-hd-4k-led-smart-tizen-tv-2025-upscaling-hdr-10-voice-assistance-remote-control-purcolor-slim-look-knox-security-100-free-channels-universal-gestures/p/itm4c86e964ab2f9"

log_file = "simple_test_log.txt"

def log(msg):
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(msg + "\n")

with open(log_file, "w", encoding="utf-8") as f:
    f.write("Starting urllib test\n")

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
}

req = urllib.request.Request(url, headers=headers)

try:
    with urllib.request.urlopen(req) as response:
        log(f"Status: {response.status}")
        content = response.read()
        log(f"Content Length: {len(content)}")
        with open("simple_test_output.html", "w", encoding="utf-8") as f:
            f.write(content.decode('utf-8', errors='ignore'))
except urllib.error.HTTPError as e:
    log(f"HTTPError: {e.code} {e.reason}")
except Exception as e:
    log(f"Exception: {e}")
