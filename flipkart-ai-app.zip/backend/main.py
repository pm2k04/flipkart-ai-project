from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from database import engine, Base
from models import Product  # Import models to ensure they are registered

# Create database tables (simple approach for now; use Alembic in production)
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Flipkart AI App Backend")

# CORS configuration
origins = [
    "http://localhost",
    "http://localhost:5173", # Vite default
    "http://localhost:3000", # React default
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"message": "Welcome to Flipkart AI App Backend"}

# Mount banners directory to serve images
from fastapi.staticfiles import StaticFiles
import os
if not os.path.exists("banners"):
    os.makedirs("banners")
app.mount("/banners", StaticFiles(directory="banners"), name="banners")

from sqlalchemy.orm import Session
from fastapi import Depends, HTTPException, BackgroundTasks
from database import get_db
import models, schemas
import scraper, image_utils, llm_utils

@app.post("/products/import", response_model=schemas.Product)
def import_product_from_url(input_data: schemas.URLInput, db: Session = Depends(get_db)):
    # Check if already exists
    existing = db.query(models.Product).filter(models.Product.flipkart_url == input_data.url).first()
    if existing:
        return existing

    # Scrape
    try:
        scraped_data = scraper.scrape_flipkart_product(input_data.url)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to scrape product: {str(e)}")

    # Generate Description via LLM
    description = llm_utils.generate_product_description(scraped_data["name"], scraped_data["category"])
    
    # Create DB Object
    db_product = models.Product(
        name=scraped_data["name"],
        price=scraped_data["price"],
        image_url=scraped_data["image_url"],
        flipkart_url=input_data.url,
        category=scraped_data["category"],
        description=description
    )
    db.add(db_product)
    db.commit()
    db.refresh(db_product)

    # Automatic Banner Generation
    if db_product.image_url:
        try:
            insta_path = image_utils.create_banner(db_product.name, db_product.price, db_product.image_url, "instagram")
            fb_path = image_utils.create_banner(db_product.name, db_product.price, db_product.image_url, "facebook")
            
            if insta_path:
                db_product.instagram_banner_path = f"/banners/{os.path.basename(insta_path)}"
            if fb_path:
                db_product.facebook_banner_path = f"/banners/{os.path.basename(fb_path)}"
            
            db.commit()
            db.refresh(db_product)
        except Exception as e:
            print(f"Auto-banner generation failed: {e}")

    return db_product

@app.get("/products", response_model=list[schemas.Product])
def get_products(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return db.query(models.Product).offset(skip).limit(limit).all()

@app.post("/products/{product_id}/generate-banner")
def generate_banner(product_id: int, platform: str = "instagram", db: Session = Depends(get_db)):
    product = db.query(models.Product).filter(models.Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    if not product.image_url:
        raise HTTPException(status_code=400, detail="Product has no image URL")

    # Generate Banner
    banner_path = image_utils.create_banner(product.name, product.price, product.image_url, platform)
    
    if not banner_path:
        raise HTTPException(status_code=500, detail="Failed to create banner")
        
    # Update DB with banner path (simplified logic, ideally store list or mapped)
    # Storing relative path for serving
    relative_path = os.path.basename(banner_path)
    full_url = f"/banners/{relative_path}"
    
    if platform == "instagram":
        product.instagram_banner_path = full_url
    else:
        product.facebook_banner_path = full_url
        
    db.commit()
    db.refresh(product)
    
    return {"message": "Banner created", "path": full_url, "product": product}
