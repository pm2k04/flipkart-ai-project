
import requests
import json
import sys

# Samsung TV URL (verified working with new scraper)
url = "https://www.flipkart.com/samsung-crystal-4k-infinity-vision-108-cm-43-inch-ultra-hd-4k-led-smart-tizen-tv-2025-upscaling-hdr-10-voice-assistance-remote-control-purcolor-slim-look-knox-security-100-free-channels-universal-gestures/p/itm4c86e964ab2f9"

with open("verify_api_log.txt", "w") as f:
    f.write(f"Testing API with URL: {url}\n")
    print(f"Testing API with URL: {url}")

    try:
        response = requests.post(
            "http://localhost:8000/products/import",
            json={"url": url},
            timeout=30
        )
        
        msg = f"Status Code: {response.status_code}\nResponse: {response.text}\n"
        f.write(msg)
        print(msg)
        
        if response.status_code == 200:
            f.write("Success! Backend is using updated scraper.\n")
        else:
            f.write("Failure. Backend might be stale.\n")
            
    except Exception as e:
        msg = f"Error connecting to backend: {e}\nBackend might not be running.\n"
        f.write(msg)
        print(msg)
