
import mysql.connector

# Connect to MySQL
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="prince1234",
    database="flipkart_app"
)
cursor = mydb.cursor()

# Delete all to clear bad data
cursor.execute("DELETE FROM products")
print("Deleted existing rows.")

# Insert fresh valid record
sql = """
INSERT INTO products (name, price, image_url, flipkart_url, category, description) 
VALUES (
    'Apple iPhone 15 (Black, 128 GB)',
    79900.0,
    'https://via.placeholder.com/400x400.png?text=Apple+iPhone+15',
    'https://www.flipkart.com/apple-iphone-15-black-128-gb/p/itm6eb39da622cdd',
    'Mobiles',
    'Experience the dynamic island and 48MP camera.'
)
"""
cursor.execute(sql)
mydb.commit()
print(f"Inserted fresh row. ID: {cursor.lastrowid}")


mydb.close()
