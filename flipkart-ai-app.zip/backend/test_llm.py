from llm_utils import generate_product_description
import os
import sys
from dotenv import load_dotenv
from pathlib import Path

# Force UTF-8 output for Windows consoles
sys.stdout.reconfigure(encoding='utf-8')

# Load .env from the same directory as this script
env_path = Path(__file__).parent / '.env'
load_dotenv(dotenv_path=env_path)

# ... imports ...
key = os.getenv("GOOGLE_API_KEY")

log_path = Path(__file__).parent / "test_llm_log.txt"

with open(log_path, "w", encoding="utf-8") as f:
    f.write(f"Key loaded: {'Yes' if key else 'No'}\n")

    if not key:
        f.write("Please set GOOGLE_API_KEY in .env file.\n")
    else:
        print("Generating description...") # Keep print for debug if needed
        try:
            desc = generate_product_description("Samsung Galaxy S24", "Mobile Phones")
            f.write(f"Result:\n{desc}\n")
        except Exception as e:
            f.write(f"Error: {e}\n")
