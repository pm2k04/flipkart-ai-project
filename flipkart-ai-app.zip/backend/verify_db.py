
import mysql.connector
from database import SessionLocal, engine
from models import Product, Base
from sqlalchemy import inspect

def check_tables_and_data():
    # 1. Check if table exists
    inspector = inspect(engine)
    tables = inspector.get_table_names()
    print(f"Tables in DB: {tables}")
    
    if "products" not in tables:
        print("Error: 'products' table not found!")
        # Attempt to create it explicitly if missing (though main.py should have)
        Base.metadata.create_all(bind=engine)
        print("Created 'products' table.")
    else:
        print("'products' table confirmed.")

    # 2. Insert dummy data using SQLAlchemy session
    db = SessionLocal()
    try:
        # Check if dummy product exists
        test_url = "http://dummy.com/test-product"
        existing = db.query(Product).filter(Product.flipkart_url == test_url).first()
        
        if not existing:
            new_product = Product(
                name="Test Product",
                price=123.45,
                image_url="http://dummy.com/image.jpg",
                flipkart_url=test_url,
                category="Test",
                description="This is a test product to verify MySQL persistence."
            )
            db.add(new_product)
            db.commit()
            db.refresh(new_product)
            print(f"Inserted new product: {new_product.name} with ID: {new_product.id}")
        else:
            print(f"Test product already exists with ID: {existing.id}")
            
    except Exception as e:
        print(f"Error inserting data: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    try:
        check_tables_and_data()
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"CRITICAL ERROR: {e}")
