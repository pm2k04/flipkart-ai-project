from sqlalchemy import Column, Integer, String, Float, Text
from database import Base

class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), index=True)
    price = Column(Float)
    image_url = Column(String(500))
    flipkart_url = Column(String(500), unique=True)
    description = Column(Text, nullable=True)
    category = Column(String(100), index=True)
    instagram_banner_path = Column(String(500), nullable=True)
    facebook_banner_path = Column(String(500), nullable=True)
