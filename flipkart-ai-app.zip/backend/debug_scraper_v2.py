
import sys
import os

log_file = "scraper_debug_v2.log"

def log(msg):
    print(msg)
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(msg + "\n")

# Clear log
with open(log_file, "w", encoding="utf-8") as f:
    f.write("Starting Debug Session\n")

# 1. Check Imports
log("Checking imports...")
try:
    import requests
    log(f"requests version: {requests.__version__}")
except ImportError as e:
    log(f"Failed to import requests: {e}")

cffi_available = False
try:
    from curl_cffi import requests as cffi_requests
    log("curl_cffi imported successfully.")
    cffi_available = True
except ImportError as e:
    log(f"Failed to import curl_cffi: {e}")

# 2. Define URL
url = "https://www.flipkart.com/samsung-crystal-4k-infinity-vision-108-cm-43-inch-ultra-hd-4k-led-smart-tizen-tv-2025-upscaling-hdr-10-voice-assistance-remote-control-purcolor-slim-look-knox-security-100-free-channels-universal-gestures/p/itm4c86e964ab2f9"
log(f"Target URL: {url}")

# 3. Test Standard Requests
log("\n--- Testing Standard Requests ---")
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.google.com/"
}
try:
    r = requests.get(url, headers=headers, timeout=10, verify=False)
    log(f"Status: {r.status_code}")
    log(f"Content-Type: {r.headers.get('Content-Type')}")
    if r.status_code == 200:
        log("Success! Standard requests worked.")
    else:
        log("Standard requests failed.")
        # Log snippet
        log(f"Response snippet: {r.text[:200]}")
except Exception as e:
    log(f"Standard requests exception: {e}")

# 4. Test curl_cffi
if cffi_available:
    log("\n--- Testing curl_cffi ---")
    impersonations = ["chrome120", "chrome110"]
    for imp in impersonations:
        log(f"Testing impersonation: {imp}")
        try:
            r = cffi_requests.get(url, impersonate=imp, timeout=10, verify=False)
            log(f"Status: {r.status_code}")
            if r.status_code == 200:
                log(f"Success with {imp}!")
                break
            else:
                 log(f"Failed with {imp}")
        except Exception as e:
            log(f"Exception with {imp}: {e}")
else:
    log("\nSkipping curl_cffi tests (not available)")

