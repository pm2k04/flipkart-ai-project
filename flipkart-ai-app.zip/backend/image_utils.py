from PIL import Image, ImageDraw, ImageFont
import requests
from io import BytesIO
import os

BANNER_DIR = "banners"
if not os.path.exists(BANNER_DIR):
    os.makedirs(BANNER_DIR)

def download_image(url: str):
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Referer": "https://www.flipkart.com/"
        }
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        return Image.open(BytesIO(response.content))
    except Exception as e:
        print(f"Error downloading image: {e}")
        return None

def create_banner(product_name: str, price: float, image_url: str, platform: str = "instagram"):
    img = download_image(image_url)
    if not img:
        return None
    
    # Dimensions
    if platform == "instagram":
        target_size = (1080, 1080)
    else: # facebook
        target_size = (1200, 630)
    
    # Create canvas
    banner = Image.new("RGB", target_size, "#ffffff")
    draw = ImageDraw.Draw(banner)
    
    # Resize product image to fit nicely
    img.thumbnail((target_size[0] // 2, target_size[1] // 2))
    
    # Paste image in center (roughly)
    img_x = (target_size[0] - img.width) // 2
    img_y = (target_size[1] - img.height) // 2 - 50
    banner.paste(img, (img_x, img_y))
    
    # Add Text
    # Use default font if custom not available, but try to load one if possible
    try:
        font_title = ImageFont.truetype("arial.ttf", 60)
        font_price = ImageFont.truetype("arial.ttf", 50)
    except IOError:
        font_title = ImageFont.load_default()
        font_price = ImageFont.load_default()

    # Draw Title
    text_color = "#000000"
    # Simple wrapping or truncation for title
    safe_title = (product_name[:30] + '..') if len(product_name) > 30 else product_name
    
    # Center text logic (simplified)
    # text_width = draw.textlength(safe_title, font=font_title) # PIL >= 9.2
    # For older PIL:
    text_bbox = draw.textbbox((0,0), safe_title, font=font_title)
    text_width = text_bbox[2] - text_bbox[0]
    
    text_x = (target_size[0] - text_width) // 2
    text_y = img_y + img.height + 20
    
    draw.text((text_x, text_y), safe_title, font=font_title, fill=text_color)
    
    # Draw Price
    price_text = f"Only ₹{price}"
    price_bbox = draw.textbbox((0,0), price_text, font=font_price)
    price_width = price_bbox[2] - price_bbox[0]
    
    price_x = (target_size[0] - price_width) // 2
    price_y = text_y + 80
    
    draw.text((price_x, price_y), price_text, font=font_price, fill="#ff0000")
    
    # Save
    filename = f"{platform}_{int(price)}_{random.randint(1000,9999)}.png"
    save_path = os.path.join(BANNER_DIR, filename)
    banner.save(save_path)
    
    return save_path

import random # re-import for the random usage above
