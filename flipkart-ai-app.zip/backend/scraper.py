import requests
from bs4 import BeautifulSoup
import time
import random

# ... (rest of imports)

def scrape_flipkart_product(url: str):
    # Robust headers to mimic a real browser
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-User": "?1",
        "TE": "trailers",
        "Referer": "https://www.flipkart.com/"
    }

    print(f"Scraping URL: {url}")
    
    try:
        # Add a random small delay to be polite and avoid some bot detection
        time.sleep(random.uniform(1, 3))
        
        response = requests.get(url, headers=headers, timeout=20, verify=False)
        
        if response.status_code == 429:
            raise Exception("Rate limit exceeded (HTTP 429). Please try again later.")
            
        if response.status_code != 200:
            print(f"Failed to fetch page. Status: {response.status_code}")
            # Try to save debug info
            try:
                with open("scraper_debug.html", "w", encoding="utf-8") as f:
                    f.write(response.text)
            except:
                pass
            raise Exception(f"Failed to fetch page. Status: {response.status_code}")
        
        # Success - save debug html
        try:
             with open("scraper_debug.html", "w", encoding="utf-8") as f:
                f.write(response.text)
        except:
            pass
        
        soup = BeautifulSoup(response.content, "html.parser")
        
        # Selectors
        # Title
        title = "Unknown Product"
        title_candidates = [
            soup.find("h1", {"class": "yhB1nd"}), 
            soup.find("span", {"class": "B_NuCI"}),
            soup.find("h1", {"class": "_6EBuvT"}), 
            soup.find("span", {"class": "VU-ZEz"}),
            soup.find("h1", {"class": "CEn5rD"}), # Found in Samsung HTML
            soup.find("h1")
        ]
        for cand in title_candidates:
            if cand:
                title = cand.get_text(strip=True)
                break
        
        # Price
        price = 0.0
        price_candidates = [
            soup.find("div", {"class": "_30jeq3 _16Jk6d"}), 
            soup.find("div", {"class": "_30jeq3"}),
            soup.find("div", {"class": "Nx9bqj CxhGGd"}), 
            soup.find("div", {"class": "Nx9bqj"}),
            soup.find("div", {"class": "hZ3P6w bnqy13"}), # Found in Samsung HTML
            soup.find("div", {"class": "hZ3P6w"})
        ]
        
        for cand in price_candidates:
            if cand:
                price_text = cand.get_text(strip=True)
                try:
                    price = float(price_text.replace("₹", "").replace(",", "").replace("Rs.", "").strip())
                    if price > 0: break
                except:
                    continue

        # Image
        image_url = None
        img_candidates = soup.find_all("img", {"class": "_396cs4"})
        if img_candidates:
            image_url = img_candidates[0].get("src")
            
        if not image_url:
            meta_img = soup.find("meta", property="og:image")
            if meta_img:
                image_url = meta_img.get("content")

        if not image_url:
             images = soup.find_all("img")
             for img in images:
                 src = img.get("src", "")
                 if "rukminim" in src and "/image" in src:
                     image_url = src
                     break

        if image_url and image_url.startswith("//"):
            image_url = "https:" + image_url

        # Category
        category = "Uncategorized"
        breadcrumbs = soup.find_all("a", {"class": "_2whKao"})
        if not breadcrumbs:
            breadcrumbs = soup.find_all("a", {"class": "zEfFJL"}) # Found in Samsung HTML
            
        if len(breadcrumbs) > 1:
            category = breadcrumbs[1].get_text(strip=True)

        print(f"Scraped: Name={title}, Price={price}, Image={image_url}")

        if title == "Unknown Product" and price == 0.0:
            # Maybe we got a 200 OK but it's a captcha or error page
            raise Exception("Scraping failed (Soft 200). Logic couldn't find details.")

        return {
            "name": title,
            "price": price,
            "image_url": image_url,
            "category": category,
            "flipkart_url": url
        }

    except Exception as e:
        print(f"Error scraping {url}: {e}")
        raise e
