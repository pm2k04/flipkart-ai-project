from pydantic import BaseModel
from typing import Optional

class ProductBase(BaseModel):
    name: str
    price: float
    image_url: Optional[str] = None
    flipkart_url: str
    description: Optional[str] = None
    category: Optional[str] = None

class ProductCreate(ProductBase):
    pass

class Product(ProductBase):
    id: int
    instagram_banner_path: Optional[str] = None
    facebook_banner_path: Optional[str] = None

    class Config:
        orm_mode = True

class URLInput(BaseModel):
    url: str
