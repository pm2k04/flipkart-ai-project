
import mysql.connector

try:
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="prince1234",
        database="flipkart_app"
    )
    cursor = mydb.cursor(dictionary=True)
    
    cursor.execute("SELECT * FROM products")
    rows = cursor.fetchall()
    
    print(f"Total rows: {len(rows)}")
    with open("db_dump.txt", "w") as f:
        f.write(f"Total rows: {len(rows)}\n")
        for row in rows:
            f.write(f"ID: {row['id']}, Name: {row['name']}, Price: {row['price']}, Image: {row['image_url']}, Insta: {row['instagram_banner_path']}, FB: {row['facebook_banner_path']}\n")

    mydb.close()
except Exception as e:
    with open("db_dump.txt", "w") as f:
        f.write(f"Error: {e}")
    print(f"Error: {e}")
