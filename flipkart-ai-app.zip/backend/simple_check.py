
import mysql.connector
import sys

print("Starting checks...", flush=True)
try:
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="prince1234",
        database="flipkart_app"
    )
    cursor = mydb.cursor()
    cursor.execute("SHOW TABLES")
    tables = [x[0] for x in cursor.fetchall()]
    print(f"Tables found: {tables}", flush=True)
    
    if "products" in tables:
        print("SUCCESS: products table exists.", flush=True)
        # INSERT DATA
        sql = "INSERT IGNORE INTO products (name, price, image_url, flipkart_url, category, description) VALUES (%s, %s, %s, %s, %s, %s)"
        val = ("Test Product From Workbench", 123.45, "http://example.com/img.jpg", "http://example.com/test-prod-workbench", "Test", "Created via script")
        cursor.execute(sql, val)
        mydb.commit()
        print(f"Inserted/Ignored row. ID: {cursor.lastrowid}", flush=True)

        # Check rows again
        cursor.execute("SELECT count(*) FROM products")
        count = cursor.fetchone()[0]
        print(f"Row count: {count}", flush=True)
    else:
        print("FAILURE: products table missing.", flush=True)
        
except Exception as e:
    print(f"Error: {e}", flush=True)
