
import mysql.connector

def create_database():
    try:
        # Connect to MySQL Server (no db selected yet)
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="prince1234"
        )
        mycursor = mydb.cursor()
        
        # Create DB
        mycursor.execute("CREATE DATABASE IF NOT EXISTS flipkart_app")
        print("Database 'flipkart_app' created or already exists.")
        
        mycursor.close()
        mydb.close()
    except Exception as e:
        print(f"Error creating database: {e}")

if __name__ == "__main__":
    create_database()
