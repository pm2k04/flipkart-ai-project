
from image_utils import download_image, create_banner
import os
import requests

url = "https://rukminim2.flixcart.com/image/416/416/xif0q/mobile/h/d/9/-original-imagtc2qzgnn8038.jpeg?q=70"

with open("test_result.txt", "w") as f:
    f.write(f"Testing image download from: {url}\n")
    
    # Debug direct request
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        }
        res = requests.get(url, headers=headers)
        f.write(f"Direct Request Status: {res.status_code}\n")
        f.write(f"Direct Request Content Type: {res.headers.get('Content-Type')}\n")
    except Exception as e:
         f.write(f"Direct Request Error: {e}\n")

    img = download_image(url)
    if img:
        f.write("Success: Image downloaded.\n")
        save_path = "test_download.png"
        img.save(save_path)
        # ...
        f.write(f"Saved to {save_path}\n")
        
        f.write("Testing banner creation...\n")
        try:
            banner_path = create_banner("Test Product", 79900.0, url, "instagram")
            if banner_path:
                f.write(f"Success: Banner created at {banner_path}\n")
            else:
                f.write("Failed: Banner creation returned None\n")
        except Exception as e:
            f.write(f"Error creating banner: {e}\n")
    else:
        f.write("Failed: Image download returned None.\n")
