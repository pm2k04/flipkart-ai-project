
import mysql.connector

try:
    print("Connecting to database...")
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="prince1234",
        database="flipkart_app"
    )
    cursor = mydb.cursor()
    
    print("Dropping valid table if exists (optional cleanup)...")
    # cursor.execute("DROP TABLE IF EXISTS products") # Uncomment if we want a fresh start, better to just create if not exists
    
    print("Creating table products...")
    sql = """
    CREATE TABLE IF NOT EXISTS products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255),
        price FLOAT,
        image_url VARCHAR(500),
        flipkart_url VARCHAR(500) UNIQUE,
        description TEXT,
        category VARCHAR(100),
        instagram_banner_path VARCHAR(500),
        facebook_banner_path VARCHAR(500),
        INDEX (name),
        INDEX (category)
    )
    """
    cursor.execute(sql)
    print("Table 'products' created successfully.")
    
    mydb.close()
    
except Exception as e:
    print(f"FAILED: {e}")
