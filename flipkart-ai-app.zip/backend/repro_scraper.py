
import logging
from scraper import scrape_flipkart_product
from image_utils import download_image
import sys

# Setup basic logging to stdout
logging.basicConfig(level=logging.INFO, stream=sys.stdout)

# Test URLs
urls = [
    "https://www.flipkart.com/samsung-crystal-4k-infinity-vision-108-cm-43-inch-ultra-hd-4k-led-smart-tizen-tv-2025-upscaling-hdr-10-voice-assistance-remote-control-purcolor-slim-look-knox-security-100-free-channels-universal-gestures/p/itm4c86e964ab2f9"
]

with open("repro_log.txt", "w") as f:
    for url in urls:
        msg = f"Testing scraper with URL: {url}\n"
        print(msg)
        f.write(msg)
        try:
            data = scrape_flipkart_product(url)
            msg = f"Successfully scraped: {data}\n"
            print(msg)
            f.write(msg)
            
            if data['image_url']:
                print(f"Testing image download: {data['image_url']}")
                img = download_image(data['image_url'])
                if img:
                    print(f"Image downloaded successfully: {img.size}")
                    f.write(f"Image downloaded successfully: {img.size}\n")
                else:
                    print("Image download failed.")
                    f.write("Image download failed.\n")
            
        except Exception as e:
            msg = f"Exception during scraping: {e}\n"
            print(msg)
            f.write(msg)
        f.write("\n")
