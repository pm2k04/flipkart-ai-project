import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { LayoutDashboard, ShoppingBag, Plus, Image as ImageIcon } from 'lucide-react';
import './index.css';

// Components (Inline for now to speed up, can extract later)
const ProductCard = ({ product, onGenerateBanner }) => {
          return (
                    <div className="glass-card p-4 rounded-xl flex flex-col gap-3 transition-transform hover:scale-105">
                              <div className="relative h-48 w-full rounded-lg overflow-hidden">
                                        <img src={product.image_url} alt={product.name} className="object-cover w-full h-full" />
                                        <div className="absolute top-2 right-2 glass-tag px-2 py-1 text-xs font-bold text-white rounded">
                                                  {product.category}
                                        </div>
                              </div>
                              <div className="flex-1">
                                        <h3 className="font-bold text-lg text-white truncate">{product.name}</h3>
                                        <p className="text-gray-300 text-sm mt-1 line-clamp-2">{product.description}</p>
                                        <div className="mt-2 text-xl font-bold text-accent">₹{product.price}</div>
                              </div>
                              <div className="flex gap-2 mt-2">
                                        <button
                                                  onClick={() => onGenerateBanner(product.id, 'instagram')}
                                                  className="btn-primary flex-1 text-xs flex items-center justify-center gap-1"
                                        >
                                                  <ImageIcon size={14} /> Insta Banner
                                        </button>
                                        <button
                                                  onClick={() => onGenerateBanner(product.id, 'facebook')}
                                                  className="btn-secondary flex-1 text-xs flex items-center justify-center gap-1"
                                        >
                                                  <ImageIcon size={14} /> FB Banner
                                        </button>
                              </div>
                              {/* Banners Preview */}
                              {(product.instagram_banner_path || product.facebook_banner_path) && (
                                        <div className="grid grid-cols-2 gap-2 mt-3 p-2 bg-white/5 rounded-lg">
                                                  {product.instagram_banner_path && (
                                                            <div className="flex flex-col gap-1">
                                                                      <span className="text-[10px] text-gray-400 uppercase tracking-wider">Instagram</span>
                                                                      <a href={`http://localhost:8000${product.instagram_banner_path}`} target="_blank" rel="noreferrer" className="block overflow-hidden rounded group">
                                                                                <img
                                                                                          src={`http://localhost:8000${product.instagram_banner_path}`}
                                                                                          alt="Instagram Banner"
                                                                                          className="w-full h-24 object-cover transform group-hover:scale-110 transition-transform duration-500"
                                                                                />
                                                                      </a>
                                                            </div>
                                                  )}
                                                  {product.facebook_banner_path && (
                                                            <div className="flex flex-col gap-1">
                                                                      <span className="text-[10px] text-gray-400 uppercase tracking-wider">Facebook</span>
                                                                      <a href={`http://localhost:8000${product.facebook_banner_path}`} target="_blank" rel="noreferrer" className="block overflow-hidden rounded group">
                                                                                <img
                                                                                          src={`http://localhost:8000${product.facebook_banner_path}`}
                                                                                          alt="Facebook Banner"
                                                                                          className="w-full h-24 object-cover transform group-hover:scale-110 transition-transform duration-500"
                                                                                />
                                                                      </a>
                                                            </div>
                                                  )}
                                        </div>
                              )}
                    </div>
          );
};

function App() {
          const [url, setUrl] = useState('');
          const [products, setProducts] = useState([]);
          const [loading, setLoading] = useState(false);
          const [refresh, setRefresh] = useState(0);

          useEffect(() => {
                    fetchProducts();
          }, [refresh]);

          const fetchProducts = async () => {
                    try {
                              const res = await axios.get('http://localhost:8000/products');
                              setProducts(res.data);
                    } catch (e) {
                              console.error("Failed to fetch products", e);
                    }
          };

          const handleImport = async (e) => {
                    e.preventDefault();
                    if (!url) return;
                    setLoading(true);
                    try {
                              await axios.post('http://localhost:8000/products/import', { url });
                              setUrl('');
                              setRefresh(prev => prev + 1);
                    } catch (error) {
                              const msg = error.response?.data?.detail || 'Error importing product. Please check the URL.';
                              alert(msg);
                    } finally {
                              setLoading(false);
                    }
          };

          const handleGenerateBanner = async (id, platform) => {
                    try {
                              await axios.post(`http://localhost:8000/products/${id}/generate-banner?platform=${platform}`);
                              setRefresh(prev => prev + 1);
                              alert(`${platform} Banner Generated!`);
                    } catch (e) {
                              alert('Error generating banner');
                    }
          };

          return (
                    <div className="min-h-screen bg-gradient text-white font-sans p-8">
                              <div className="max-w-6xl mx-auto">
                                        <header className="flex justify-between items-center mb-10">
                                                  <div className="flex items-center gap-3">
                                                            <div className="p-3 bg-accent rounded-lg shadow-lg shadow-accent/50">
                                                                      <ShoppingBag className="text-white" size={24} />
                                                            </div>
                                                            <h1 className="text-3xl font-bold tracking-tight">Flipkart<span className="text-accent">AI</span></h1>
                                                  </div>
                                                  <p className="text-white/60 text-sm">Automated Social Media Marketing</p>
                                        </header>

                                        {/* Input Section */}
                                        <div className="glass-panel p-6 mb-10 rounded-2xl animate-fade-in-up">
                                                  <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                                                            <Plus size={20} /> Import New Product
                                                  </h2>
                                                  <form onSubmit={handleImport} className="flex flex-col md:flex-row gap-4">
                                                            <input
                                                                      type="text"
                                                                      placeholder="Paste Flipkart Product URL here..."
                                                                      className="flex-1 glass-input px-4 py-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-accent/50 text-white placeholder-white/40"
                                                                      value={url}
                                                                      onChange={(e) => setUrl(e.target.value)}
                                                            />
                                                            <button
                                                                      type="submit"
                                                                      disabled={loading}
                                                                      className="btn-primary px-8 py-3 rounded-xl font-bold shadow-lg shadow-accent/30 hover:shadow-accent/50 transition-all disabled:opacity-50"
                                                            >
                                                                      {loading ? 'Importing...' : 'Import Product'}
                                                            </button>
                                                  </form>
                                        </div>

                                        {/* Dashboard Grid */}
                                        <div className="flex items-center gap-2 mb-6">
                                                  <LayoutDashboard size={20} className="text-accent" />
                                                  <h2 className="text-2xl font-bold">Product Dashboard</h2>
                                        </div>

                                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                                  {products.map(p => (
                                                            <ProductCard key={p.id} product={p} onGenerateBanner={handleGenerateBanner} />
                                                  ))}
                                                  {products.length === 0 && (
                                                            <div className="col-span-full text-center py-20 text-white/30">
                                                                      No products yet. Import one above!
                                                            </div>
                                                  )}
                                        </div>
                              </div>
                    </div>
          )
}

export default App
