from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

from dotenv import load_dotenv

load_dotenv()

# Database URL
# Default to SQLite for easy local setup, can be changed to MySQL via environment variable
# MySQL format: mysql+mysqlconnector://user:password@host/db_name
# DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./flipkart_app.db")
DATABASE_URL = "mysql+mysqlconnector://root:prince1234@localhost/flipkart_app"
with open("startup_log.txt", "w") as f:
    f.write(f"Connecting to database: {DATABASE_URL}")
print(f"Connecting to database: {DATABASE_URL}")

engine = create_engine(
    DATABASE_URL, connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {}
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
