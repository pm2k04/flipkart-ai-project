
import requests

url = "https://www.flipkart.com/samsung-crystal-4k-infinity-vision-108-cm-43-inch-ultra-hd-4k-led-smart-tizen-tv-2025-upscaling-hdr-10-voice-assistance-remote-control-purcolor-slim-look-knox-security-100-free-channels-universal-gestures/p/itm4c86e964ab2f9"

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "TE": "trailers"
}

print(f"Requesting {url}...")
try:
    response = requests.get(url, headers=headers, timeout=15, verify=False)
    print(f"Status Code: {response.status_code}")
    print(f"Content Length: {len(response.content)}")
    if response.status_code == 200:
        print("Success!")
        with open("simple_test_output.html", "w", encoding="utf-8") as f:
            f.write(response.text)
    else:
        print("Failed.")
except Exception as e:
    print(f"Exception: {e}")
