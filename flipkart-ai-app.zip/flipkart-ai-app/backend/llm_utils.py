import os
import google.generativeai as genai
from dotenv import load_dotenv
from pathlib import Path

# Load .env from the same directory as this file
env_path = Path(__file__).parent / '.env'
load_dotenv(dotenv_path=env_path)

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

if GOOGLE_API_KEY:
    genai.configure(api_key=GOOGLE_API_KEY)

def generate_product_description(product_name: str, category: str):
    if not GOOGLE_API_KEY:
        print("Warning: GOOGLE_API_KEY not found. Using mock response.")
        return f"🔥 check out this amazing {product_name}! It's the best in {category}. Grab it now! #Flipkart #{category}"
    
    try:
        model = genai.GenerativeModel('gemini-pro')
        prompt = f"Write a catchy social media post for {product_name} in category {category}. Highlight features. Keep it under 50 words."
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        print(f"Error generating description with LLM: {e}")
        return f"🔥 check out this amazing {product_name}! It's the best in {category}. Grab it now! #Flipkart #{category}"

def generate_details_with_llm(name: str):
    return generate_product_description(name, "General")
