import os
# from google.generativeai import configure, GenerativeModel # Example for Gemini
# import openai # For OpenAI

# Mock LLM for now if no key provided, otherwise implement basic call
# You can uncomment and configure based on actual user preference/Key

def generate_product_description(product_name: str, category: str):
    
    prompt = f"Write a catchy social media post for {product_name} in category {category}. Highlight features."
    

    return f"🔥 check out this amazing {product_name}! It's the best in {category}. Grab it now! #Flipkart #{category}"

def generate_details_with_llm(name: str):
    return generate_product_description(name, "General")
